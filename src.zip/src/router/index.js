import Vue from 'vue'
import VueRouter from 'vue-router'
import Layout from '@/views/Layout'
import Screen from '@/views/Screen'
import Register from '@/views/Register' 
import ScreenList from '@/views/ScreenList'
import ScreenNull from '@/views/ScreenNull'

Vue.use(VueRouter)

const routes = [
    {
        path:"/",
        redirect: "/layout"
    },
    {
        path: "/layout",
        component:Layout, 
        children: [
           {
                path: "screen",
                component: Screen,
                children: [
                    {
                        path:"screenlist",
                        component:ScreenList,
                    },
                    {
                        path: 'screennull',
                        component: ScreenNull,
                    }
                ]
           },
           {
                path: "register",
                component: Register
           }
        ]
    }
]
const router = new VueRouter({
    routes
})
export default router