<template>
  <div class="modify-box">
    <div class="modify-header">
         <!-- 顶部状态栏 -->
        <div class="login-top">
            <div class="time-box">
                9:41
            </div>
            <div class="signal">
                <img src="@/assets/images/signal.png" alt="img">
            </div>
            <div class="wifi">
                <img src="@/assets/images/wifi.png" alt="img">
            </div>
            <div class="electric">
                <img src="@/assets/images/electric.png" alt="img">
            </div>
        </div>
        <div class="modify-inner">
            <button>&lt;</button>
            <div class="modify-pwd">
                修改密码
            </div>
        </div>
    </div>
    <div class="modify-content">
        <form>
            <div class="account-box">
            <div class="account">账号</div>
            <input type="text" placeholder="请输入账号" v-model="account">
        </div>
        <div class="pwd-old">
            <div class="pwd">原密码</div>
            <input type="text" placeholder="请输入原密码" v-model="opassword">
        </div>
        <div class="pwd-new">
            <div class="pwd">新密码</div>
            <input type="text" placeholder="请输入新密码" v-model="password">
        </div>
        <div class="confirm">
            <div class="pwd">确认新密码</div>
            <input type="text" placeholder="请确认新密码" v-model="npassword">
        </div>
        <div class="confirm-box">
            <button  @click="queren" >确认</button>
        </div>
        </form>
    </div>
  </div>
</template>

<script>
    export default {
        name: 'Register',
        data(){
            return {
                account: '',
                password: '',
                opassword: '',
                npassword: '',
            }
        },
        methods: {
            queren(){
                if (this.opassword !== this.password && this.password === this.npassword) {
                    // console.log(this)
                    localStorage.setItem('account',this.account)
                    localStorage.setItem('password',this.password)
                    this.$router.push({
                    path: "/layout",
                    })
                }
                else {
                    alert('账户名或密码错误')
                }
            }
        }
    }
</script>

<style scoped lang="scss">
    input::-webkit-input-placeholder {
        color: #D6D6D6;
    }
    input {
        outline: none;
        border: none;
        background: transparent;
        width: 232px;
        height: 20px;
        font-size: 14px;
        font-family: PingFangSC-Regular, PingFang SC;
        font-weight: 400;
        color: #D6D6D6;
        line-height: 20px;
    }
    .modify-box {
        width: 375px;
        height: 812px;
        background: #FAFAFA;
        margin: 0 auto;
        position: relative;
        .modify-header {
            width: 375px;
            height: 88px;
            background: rgba(255,255,255,0);
            margin-bottom: 28px;
            .login-top {
                padding-top: 14px;
                display: flex;
                align-items: center;
                .time-box {
                    width: 54px;
                    height: 18px;
                    font-size: 15px;
                    font-family: SFProText-Semibold, SFProText;
                    font-weight: 600;
                    color: #000;
                    line-height: 18px;
                    text-align: center;
                    margin-left: 21px;
                }
                .signal {
                    margin-left: 215px;
                    width: 17px;
                    height: 11px;
                    img {
                        display: block;
                        width: 100%;
                        height: 100%;
                        color: #000;
                    }
                }
                .wifi {
                    width: 15px;
                    height: 11px;
                    img {
                        display: block;
                        width: 100%;
                        height: 100%;
                    }
                }
                .electric {
                    width: 22px;
                    height: 11px;
                    img {
                        display: block;
                        width: 100%;
                        height: 100%;
                    }
                }
            }
            .modify-inner {
                height: 24px;
                margin-top: 22px;
                display: flex;
                justify-content: center;
                align-items: center;
                button {
                    border: none;
                    background-color: transparent;
                }
                .modify-pwd{
                    width: 295px;
                    height: 24px;
                    font-size: 17px;
                    font-family: PingFangSC-Regular, PingFang SC;
                    font-weight: 400;
                    color: #333333;
                    line-height: 24px;
                    text-align: center;
                    margin-left: 5px;
                }
            }
        }
        .modify-content {
            width: 351px;
            height: 360px;
            background: #FFFFFF;
            box-shadow: 0px 0px 4px 0px rgba(0,0,0,0.08);
            border-radius: 20px;
            margin: 0 12px;
            padding: 0 20px;
            .account-box {
                height: 56px;
                border-bottom: 1px solid #F5F5F5;
                padding-bottom: 10px;
                display: flex;
                align-items: flex-end;
            }
            .account,.pwd {
                width: 67px;
                height: 16px;
                font-size: 12px;
                font-family: PingFangSC-Regular, PingFang SC;
                font-weight: 400;
                color: #666666;
                line-height: 16px;
                margin-right: 12px;
            }
            .pwd-old,.pwd-new,.confirm {
                height: 65px;
                border-bottom: 1px solid #F5F5F5;
                padding-bottom: 10px;
                display: flex;
                align-items: flex-end;
            }
            .confirm-box {
            width: 311px;
            height: 48px;
            background: #F58287;
            border-radius: 8px;
            margin-top: 28px;
            padding: 13px 12px;
            }
            .confirm-box button {
                border: none;
                width: 287px;
                height: 22px;
                font-size: 16px;
                font-family: PingFangSC-Semibold, PingFang SC;
                font-weight: 600;
                color: #FFFFFF;
                line-height: 22px;
                background: transparent;
            }
        }
    }
   
</style>