<template>
  <div class="tickets-box">
    <div class="tickets-header">
        <div class="login-top">
            <div class="time-box">
                9:41
            </div>
            <div class="signal">
                <img src="@/assets/images/signal.png" alt="img">
            </div>
            <div class="wifi">
                <img src="@/assets/images/wifi.png" alt="img">
            </div>
            <div class="electric">
                <img src="@/assets/images/electric.png" alt="img">
            </div>
        </div>
        <div class="modify-inner">
            <button>&lt;</button>
            <div class="modify-pwd">
                券明细
            </div>
        </div>
    </div>
    <div class="tickets-content-box">
        <div class="tickets-content">
            <div class="tickets-owner">
                <div class="owner">
                    赣AJM999 &nbsp;张卫国
                </div>
                <div class="green">
                    领取完成
                </div>
            </div>
            <div class="green-box">
                <div class="batch-box">
                    <div class="batch">券次批号</div>
                    <div class="numble">1011321134</div>
                </div>
                <div class="batch-box">
                    <div class="batch">批次总金额</div>
                    <div class="numble">600.00 (GF:300.00、CX:300.00)</div>
                </div>
                <div class="batch-box">
                    <div class="batch">拆分数量</div>
                    <div class="numble">2</div>
                </div>
                <div class="batch-box">
                    <div class="batch">创建时间</div>
                    <div class="numble">2023/07/01 14:00:00</div>
                </div>
            </div>
        </div>
        <div class="details">
            ——— <span>发放详情</span> ———
            </div>
        <div class="written-box">
            <div class="batch-box">
                    <div class="batch">券面额</div>
                    <div class="numble">300</div>
                </div>
                <div class="batch-box">
                    <div class="batch">券数量</div>
                    <div class="numble">1</div>
                </div>
                <div class="batch-box">
                    <div class="batch">创建时间</div>
                    <div class="numble">2023/07/01 14:00:00</div>
                </div>
                <div class="batch-box">
                    <div class="batch">有效期</div>
                    <div class="numble">2023/07/10 14:00:00</div>
                </div>
                <div class="batch-box">
                    <div class="batch">领取时间</div>
                    <div class="numble">2023/07/02 15:00:00</div>
                </div>
                <div class="batch-box">
                    <div class="batch">状态</div>
                    <span>待核销</span>
                </div>
                <div class="batch-box">
                    <div class="batch">核销时间</div>
                    <div class="numble">2023/07/05 14:00:00</div>
                </div>
        </div>
        <div class="written-box">
            <div class="batch-box">
                    <div class="batch">券面额</div>
                    <div class="numble">300</div>
                </div>
                <div class="batch-box">
                    <div class="batch">券数量</div>
                    <div class="numble">1</div>
                </div>
                <div class="batch-box">
                    <div class="batch">创建时间</div>
                    <div class="numble">2023/07/01 14:00:00</div>
                </div>
                <div class="batch-box">
                    <div class="batch">有效期</div>
                    <div class="numble">2023/07/10 14:00:00</div>
                </div>
                <div class="batch-box">
                    <div class="batch">领取时间</div>
                    <div class="numble">2023/07/02 15:00:00</div>
                </div>
                <div class="batch-box">
                    <div class="batch">状态</div>
                    <span>待核销</span>
                </div>
                <div class="batch-box">
                    <div class="batch">核销时间</div>
                    <div class="numble">2023/07/05 14:00:00</div>
                </div>
        </div>
    </div>
  </div>
</template>

<script>
    export default {
        name: 'Tickets'
    }
</script>

<style lang="scss" scoped>
@mixin batch-box {
    display: flex;
    flex-direction: row;
    justify-content: space-between;
    margin-bottom: 14px;
}
@mixin batch {
    height: 20px;
    font-size: 14px;
    font-family: PingFangSC-Regular, PingFang SC;
    font-weight: 400;
    color: #999999;
    line-height: 20px;
}
@mixin numble {
    font-size: 14px;
    font-family: PingFangSC-Regular, PingFang SC;
    font-weight: 400;
    color: #333333;
    line-height: 20px;
}
    .tickets-box {
        width: 375px;
        height: 812px;
        margin: 0 auto;
        background: #FAFAFA;
        .tickets-header {
            width: 100%;
            height: 88px;
            background: rgba(255,255,255,0);
            .login-top {
                padding-top: 14px;
                display: -webkit-box;
                display: -ms-flexbox;
                display: flex;
                -webkit-box-align: center;
                -ms-flex-align: center;
                align-items: center;
            }
            .login-top .time-box {
                    width: 54px;
                    height: 18px;
                    font-size: 15px;
                    font-family: SFProText-Semibold, SFProText;
                    font-weight: 600;
                    color: #000;
                    line-height: 18px;
                    text-align: center;
                    margin-left: 21px;
            }
            .login-top .signal {
                    margin-left: 215px;
                    width: 17px;
                    height: 11px;
            }
            .login-top .signal img {
                    display: block;
                    width: 100%;
                    height: 100%;
                    color: #000;
            }
            .login-top .wifi {
                    width: 15px;
                    height: 11px;
            }
            .login-top .wifi img {
                    display: block;
                    width: 100%;
                    height: 100%;
            }
            .login-top .electric {
                    width: 22px;
                    height: 11px;
            }
            .login-top .electric img {
                    display: block;
                    width: 100%;
                    height: 100%;
            }
            .modify-inner {
                height: 24px;
                margin-top: 22px;
                display: flex;
                justify-content: center;
                align-items: center;
            }
            .modify-inner button {
                border: none;
                background-color: transparent;
            }
            .modify-inner .modify-pwd{
                width: 295px;
                height: 24px;
                font-size: 17px;
                font-family: PingFangSC-Regular, PingFang SC;
                font-weight: 400;
                color: #333333;
                line-height: 24px;
                text-align: center;
                margin-left: 5px;
            }
        }
        .tickets-content-box {
            width: 100%;
            padding: 0 12px;
            .tickets-content {
                margin-top: 12px;
                padding: 0 16px;
                width: 351px;
                height: 248px;
                background: linear-gradient(180deg, rgba(69,191,17,0.1) 0%, rgba(255,255,255,1) 100%);
                border-radius: 0px 0px 8px 8px;
                border-top: 3px solid #45BF11;
                .tickets-owner {
                    width: 100%;
                    height: 54px;
                    margin-top: 28px;
                    display: flex;
                    flex-direction: column;
                    justify-content: center;
                    align-items: center;
                    .owner {
                        font-size: 20px;
                        font-family: PingFangSC-Medium, PingFang SC;
                        font-weight: 500;
                        color: #333333;
                        line-height: 28px;
                        margin-bottom: 6px;
                    }
                    .green {
                        width: 56px;
                        height: 16px;
                        background: #45BF11;
                        border-radius: 2px;
                        font-size: 12px;
                        font-family: PingFangSC-Regular, PingFang SC;
                        font-weight: 400;
                        color: #FFFFFF;
                        line-height: 16px;
                    }
                }
                .green-box {
                    width: 100%;
                    height: 140px;
                    margin-top: 26px;
                    .batch-box {
                        @include batch-box;
                        .batch {
                            @include batch
                        }
                        .numble {
                           @include numble
                        }
                    }
                }
            
            }
            .details {
                width: 100%;
                height: 20px;
                margin-top: 20px;
                font-size: 14px;
                font-family: PingFangSC-Regular, PingFang SC;
                font-weight: 400;
                color: #d6d6d6;
                line-height: 20px;
                text-align: center;
                span {
                    margin: 0 16px;
                    color: #333333;
                }
            }
            .written-box {
                width: 351px;
                height: 244px;
                margin-top: 12px;
                padding: 16px;
                background: #fff;
                box-shadow: 0px 0px 4px 0px rgba(0,0,0,0.08);
                border-radius: 8px;
                .batch-box {
                    @include batch-box;
                    .batch {
                        @include batch
                    }
                    .numble {
                        @include numble
                    }
                    span {
                        width: 48px;
                        height: 20px;
                        font-size: 12px;
                        font-family: PingFangSC-Regular, PingFang SC;
                        font-weight: 400;
                        color: #2061E6;
                        line-height: 20px;
                        background: #DEEEFC;
                        border-radius: 2px;
                        text-align: center;
                    }
                }
            }
        }
    }
</style>