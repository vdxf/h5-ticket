<template>
  <div class="popup">
    <div class="content-box">
        <div class="content-top">
            <div class="prompt">
                温馨提示
            </div>
            <div class="num">
                {车牌号}本次补发券面额：100元。
            </div>
        </div>
        <div class="content-bottom">
            <div class="left-box">
                <button>取消</button>
            </div>
            <div class="right-box">
                <button>补发</button>
            </div>
        </div>
    </div>
  </div>
</template>

<script>
    export default {
        name: 'Popup',
    }
</script>

<style scoped lang="scss">
button {
    border: none;
    background: transparent;
    width: 144px;
    height: 24px;
    font-size: 17px;
    font-family: PingFangSC-Medium, PingFang SC;
    font-weight: 500;
    line-height: 24px;
    letter-spacing: 1px;
}
    .popup {
        width: 375px;
        height: 812px;
        background: rgba(0,0,0,0.4);
        margin: 0 auto;
        display: flex;
        justify-content: center;
        align-items: center;
        .content-box {
            width: 320px;
            height: 184px;
            background: #FFFFFF;
            border-radius: 8px;
            .content-top {
                width: 100%;
                height: 128px;
                border-bottom: 1px solid #D9d9d9;
                display: flex;
                flex-direction: column;
                justify-content: center;
                align-items: center;
                .prompt {
                    width: 272px;
                    height: 24px;
                    font-size: 17px;
                    font-family: PingFangSC-Medium, PingFang SC;
                    font-weight: 500;
                    color: #333333;
                    line-height: 24px;
                    text-align: center;
                    margin-bottom: 16px;
                }
                .num {
                    width: 272px;
                    height: 24px;
                    font-size: 17px;
                    font-family: PingFangSC-Regular, PingFang SC;
                    font-weight: 400;
                    color: #666666;
                    line-height: 24px;
                    text-align: center;
                }
            }
            .content-bottom {
                width: 100%;
                height: 56px;
                display: flex;
                flex-direction: row;
                .left-box {
                    width: 160px;
                    height: 100%;
                    border-right: 1px solid #D9d9d9;
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    button {
                        color: #333333;
                    }
                }
                .right-box {
                    width: 160px;
                    height: 100%;
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    button {
                        color: #2061E6;
                    }
                }
            }
        }
    }
</style>