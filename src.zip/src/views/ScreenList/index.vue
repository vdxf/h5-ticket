<template>
  <div class="screenlist">
    
   <!-- <div class="header-box">
        <div class="login-top">
            <div class="time-box">
                9:41
            </div>
            <div class="signal">
                <img src="@/assets/images/signal.png" alt="img">
            </div>
            <div class="wifi">
                <img src="@/assets/images/wifi.png" alt="img">
            </div>
            <div class="electric">
                <img src="@/assets/images/electric.png" alt="img">
            </div>
        </div>
        <div class="header-content">
            <div class="merchant">
                <a href="#">{商户名称}</a>
            </div>
            <div class="salesman">
                <a href="#">业务员名称</a>
            </div>
            <a href="#"><img src="@/assets/images/exit.png" alt="img"></a>
            <div class="exit">
                <router-link  to="/layout">退出</router-link>
            </div>
        </div>
        <div class="header-bottom">
            <div class="input-box">
                <img src="@/assets/images/search.png" alt="img">
                <input type="text" placeholder="搜索车牌号">
            </div>
            <label>
              <img src="@/assets/images/filter.png" alt="img">
             <a href="#" class="filter">筛选</a>
            </label>
        </div>
    </div> -->
    <router-view></router-view>
    <div class="content-box">
        <div class="state-title">状态</div>
        <div class="state-inner">
            <button>待发放</button>
            <button>领取完成</button>
            <button>部分领取</button>
            <button>已作废</button>
        </div>
        <div class="numberplate-title">车牌号</div>
        <div class="numberplate-input">
            <input type="text" placeholder="请输入车牌号">
        </div>
        <div class="owner-title">车主姓名</div>
        <div class="owner-input">
            <input type="text" placeholder="请输入车主姓名">
        </div>
        <div class="time-title">创建时间</div>
        <div class="time-input">
            <div class="time-input-start">
                <input type="text" placeholder="开始时间">
            </div>
            <span>-</span>
            <div class="time-input-end">
                <input type="text" placeholder="结束时间">
            </div>
        </div>
        
    </div>
    <div class="reset-inner">
            <div class="reset-button">
                <button>重置</button>
            </div>
            <div class="filter-button">
                <button @click="filter">筛选</button>
            </div>
        </div>
  </div>
</template>

<script>
    export default {
        name: 'ScreenList',
        methods: {
            filter(){
                this.$router.push({
                    path: "/layout/screen/screennull"
                })
            }
        }
    }
</script>

<style lang="scss" scoped>
input::-webkit-input-placeholder {
        color: #D6D6D6;
}
$width: 375px;
$height:812px;
$color:#fff;
$margin: 0 auto;
$position-r:relative;
$position-a:absolute;
$top:0;
$left:0;
$right:0;
$buttom:0;
$overflow: hidden;
$display-b: block;
$display-f:flex;
$align-items: center;
$text-align: center;
@mixin inputbox1 {
    width: 311px;
    height: 48px;
    background: #F5F5F5;
    border-radius: 8px;
}
@mixin inputbox2 {
    width: 351px;
    height: 36px;
    background: #F5F5F5;
    border-radius: 8px;
}
@mixin inputbox3 {
    width: 165px;
    height: 36px;
    background: #F5F5F5;
    border-radius: 8px;
}
@mixin input {
    outline: none;
    border: none;
    width: 279px;
    height: 22px;
    font-size: 16px;
    font-family: PingFangSC-Regular, PingFang SC;
    font-weight: 400;
    line-height: 22px;
    background-color: transparent;
    color: #D6D6D6;
}
@mixin input1 {
    outline: none;
    border: none;
    width: 227px;
    height: 22px;
    font-size: 16px;
    font-family: PingFangSC-Regular, PingFang SC;
    font-weight: 400;
    line-height: 22px;
    background-color: transparent;
    color: #D6D6D6;
}
@mixin input2 {
    outline: none;
    border: none;
    width: 327px;
    height: 20px;
    font-size: 14px;
    font-family: PingFangSC-Regular, PingFang SC;
    font-weight: 400;
    color: #999999;
    line-height: 20px;
    background-color: transparent;
}
@mixin input3 {
    outline: none;
    border: none;
    width: 141px;
    height: 20px;
    font-size: 14px;
    font-family: PingFangSC-Regular, PingFang SC;
    font-weight: 400;
    color: #999999;
    line-height: 20px;
    background-color: transparent;
}


@mixin title {
    height: 20px;
    font-size: 14px;
    font-family: PingFangSC-Regular, PingFang SC;
    font-weight: 400;
    color: #333333;
    line-height: 20px;
    margin-bottom: 12px;
}

$family:PingFangSC-Medium, PingFang SC;
a {
    text-decoration: none;
    color: $color;
}
.screenlist {
    width: 375px;
    height: 812px;
    margin: 0 auto;
    background: rgba(0,0,0,0.4);
    .header-box {
        width: 375px;
        height: 144px;
        background: #EB1E23;
        .login-top {
            padding-top: 14px;
            display: flex;
            align-items: center;
            .time-box {
                width: 54px;
                height: 18px;
                font-size: 15px;
                font-family: SFProText-Semibold, SFProText;
                font-weight: 600;
                color: #fff;
                line-height: 18px;
                text-align: center;
                margin-left: 21px;
            }
            .signal {
                margin-left: 215px;
                width: 17px;
                height: 11px;
                img {
                    display: block;
                    width: 100%;
                    height: 100%;
                    color: #fff;
                }
            }
            .wifi {
                width: 15px;
                height: 11px;
                img {
                    display: block;
                    width: 100%;
                    height: 100%;
                }
            }
            .electric {
                width: 22px;
                height: 11px;
                img {
                    display: block;
                    width: 100%;
                    height: 100%;
                }
            }
        }
        .header-content {
            width: 100%;
            height: 24px;
            margin-top: 22px;
            display: flex;
            align-items: center;
            justify-content: center;
            .merchant {
                margin-left: 12px;
                width: 90px;
                height: 24px;
                font-size: 18px;
                font-family: PingFangSC-Medium, PingFang SC;
                font-weight: 500;
                color: #fff;
                line-height: 24px;
            }
            .salesman {
                width: 205px;
                height: 20px;
                font-size: 15px;
                font-family: PingFangSC-Medium, PingFang SC;
                font-weight: 500;
                color: #fff;
                line-height: 20px;
            }
            img {
                display: block;
                width: 16px;
                height: 16px;
            }
            .exit {
                width: 28px;
                height: 20px;
                font-size: 14px;
                font-family: PingFangSC-Regular, PingFang SC;
                font-weight: 400;
                color: #FFFFFF;
                line-height: 20px;
                margin-left: 4px;
            }
        }
        .header-bottom {
            width: 375px;
            height: 60px;
            margin-top: 10px;
            background: #fff;
            border-radius: 20px 20px 0px 0px;
            display: flex;
            align-items: center;
            .input-box {
                width: 291px;
                height: 36px;
                background: #F5F5F5;
                border-radius: 8px;
                margin-left: 12px;
                display: flex;
                align-items: center;
                img {
                    display: block;
                    width: 16px;
                    height: 16px;
                    margin-left: 12px;
                    margin-right: 8px;
                }
                input {
                    outline: none;
                    border: none;
                    width: 227px;
                    height: 22px;
                    font-size: 16px;
                    font-family: PingFangSC-Regular, PingFang SC;
                    font-weight: 400;
                    line-height: 22px;
                    background-color: transparent;
                    color: #D6D6D6;
                }
            }
            label {
                display: flex;
                img {
                    display: block;
                    width: 16px;
                    height: 16px;
                    margin-left: 12px;
                    margin-right: 4px;
                }
                .filter {
                    width: 28px;
                    height: 20px;
                    font-size: 14px;
                    font-family: PingFangSC-Regular, PingFang SC;
                    font-weight: 400;
                    color: #EB1E23;
                    line-height: 20px;
                }
            }
        }
    }
    .content-box {
        width: 100%;
        height: 372px;
        padding: 20px 12px;
        background: linear-gradient(180deg, #FFFFFF 0%, #FAFAFA 100%);
        display: flex;
        flex-direction: column;
         .state-title {
                width: 28px;
                @include title;
                
            }
            .state-inner {
                margin-bottom: 20px;
                button {
                    border: none;
                    width: 81px;
                    height: 36px;
                    background: #F5F5F5;
                    border-radius: 8px;
                }
            }
            .numberplate-title {
                width: 42px;
                @include title;
            }
            .numberplate-input {
                @include inputbox2;
                margin-bottom: 20px;
                input {
                    @include input2;
                    margin: 8px 12px;
                    text-align: center;
                }
            }
            .owner-title {
                width: 56px;
                @include title;
            }
            .owner-input {
                @include inputbox2;
                margin-bottom: 20px;
                input {
                    @include input2;
                    margin: 8px 12px;
                    text-align: center;
                }
            }
            .time-title {
                width: 56px;
                @include title;
            }
            .time-input {
                display: flex;
                flex-direction: row;
                align-items: center;
                margin-bottom: 20px;
                .time-input-start {
                    @include inputbox3;
                    input {
                        @include input3;
                        margin: 8px 12px;
                        text-align: center;
                    }
                }
                span {
                    display: block;
                    width: 9px;
                    height: 20px;
                    font-size: 14px;
                    font-family: PingFangSC-Regular, PingFang SC;
                    font-weight: 400;
                    color: #333333;
                    line-height: 20px;
                    margin: 0 6px;
                }
                .time-input-end {
                    @include inputbox3;
                    input {
                        @include input3;
                        margin: 8px 12px;
                        text-align: center;
                    }
                }
            }
            
    }
    .reset-inner {
                height: 46px;
                display: flex;
                flex-direction: row;
                .reset-button {
                    width: 188px;
                    height: 46px;
                    border-top: 1px solid #D6D6D6;
                    background: #FFFFFF;
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    button {
                        border: none;
                        background-color: transparent;
                        color: #666;
                        margin: 11px auto;
                    }
                }
                .filter-button {
                    width: 187px;
                    height: 46px;
                    background: #EB1E23;
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    button {
                        border: none;
                        background-color: transparent;
                        color: #fff;
                        margin: 11px auto;
                    }
                }
            }
}
</style>