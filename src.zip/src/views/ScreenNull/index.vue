<template>
  <div class="screennull">
    <!-- <div class="header-box">
        <div class="login-top">
            <div class="time-box">
                9:41
            </div>
            <div class="signal">
                <img src="@/assets/images/signal.png" alt="img">
            </div>
            <div class="wifi">
                <img src="@/assets/images/wifi.png" alt="img">
            </div>
            <div class="electric">
                <img src="@/assets/images/electric.png" alt="img">
            </div>
        </div>
        <div class="header-content">
            <div class="merchant">
                <a href="#">{商户名称}</a>
            </div>
            <div class="salesman">
                <a href="#">业务员名称</a>
            </div>
            <a href="#"><img src="@/assets/images/exit.png" alt="img"></a>
            <div class="exit">
                <router-link href="#" to="/layout">退出</router-link>
            </div>
        </div>
        <div class="header-bottom">
            <div class="input-box">
                <img src="@/assets/images/search.png" alt="img">
                <input type="text" placeholder="搜索车牌号">
            </div>
            <label>
              <img src="@/assets/images/filter.png" alt="img">
             <router-link href="#" to="/layout/screen/screenlist" class="filter">筛选</router-link>
            </label>
        </div>
    </div> -->
    <div class="content-box">
        <img src="@/assets/images/null.png" alt="img">
    </div>
    <div class="login-footer">
    </div>
  </div>
</template>

<script>
export default {
    name:'Screen',
}
</script>

<style scoped>
a {
  text-decoration: none;
  color: #fff;
}
input::-webkit-input-placeholder {
        color: #D6D6D6;
    }

.screennull {
  width: 375px;
  height: 812px;
  margin: 0 auto;
  position: relative;
}
.screennull .header-box {
  width: 375px;
  height: 144px;
  background: #EB1E23;
}
.screennull .header-box .login-top {
  padding-top: 14px;
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
  -webkit-box-align: center;
      -ms-flex-align: center;
          align-items: center;
}
.screennull .header-box .login-top .time-box {
  width: 54px;
  height: 18px;
  font-size: 15px;
  font-family: SFProText-Semibold, SFProText;
  font-weight: 600;
  color: #fff;
  line-height: 18px;
  text-align: center;
  margin-left: 21px;
}
.screennull .header-box .login-top .signal {
  margin-left: 215px;
  width: 17px;
  height: 11px;
}
 .header-box .login-top .signal img {
  display: block;
  width: 100%;
  height: 100%;
  color: #fff;
}
 .header-box .login-top .wifi {
  width: 15px;
  height: 11px;
}
 .header-box .login-top .wifi img {
  display: block;
  width: 100%;
  height: 100%;
}
 .header-box .login-top .electric {
  width: 22px;
  height: 11px;
}
 .header-box .login-top .electric img {
  display: block;
  width: 100%;
  height: 100%;
}
 .header-box .header-content {
  width: 100%;
  height: 24px;
  margin-top: 22px;
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
  -webkit-box-align: center;
      -ms-flex-align: center;
          align-items: center;
  -webkit-box-pack: center;
      -ms-flex-pack: center;
          justify-content: center;
}
 .header-box .header-content .merchant {
  margin-left: 12px;
  width: 90px;
  height: 24px;
  font-size: 18px;
  font-family: PingFangSC-Medium, PingFang SC;
  font-weight: 500;
  color: #fff;
  line-height: 24px;
}
 .header-box .header-content .salesman {
  width: 205px;
  height: 20px;
  font-size: 15px;
  font-family: PingFangSC-Medium, PingFang SC;
  font-weight: 500;
  color: #fff;
  line-height: 20px;
}
 .header-box .header-content img {
  display: block;
  width: 16px;
  height: 16px;
}
 .header-box .header-content .exit {
  width: 28px;
  height: 20px;
  font-size: 14px;
  font-family: PingFangSC-Regular, PingFang SC;
  font-weight: 400;
  color: #FFFFFF;
  line-height: 20px;
  margin-left: 4px;
}
 .header-box .header-bottom {
  width: 375px;
  height: 60px;
  margin-top: 10px;
  background: #fff;
  border-radius: 20px 20px 0px 0px;
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
  -webkit-box-align: center;
      -ms-flex-align: center;
          align-items: center;
}
 .header-box .header-bottom .input-box {
  width: 291px;
  height: 36px;
  background: #F5F5F5;
  border-radius: 8px;
  margin-left: 12px;
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
  -webkit-box-align: center;
      -ms-flex-align: center;
          align-items: center;
}
 .header-box .header-bottom .input-box img {
  display: block;
  width: 16px;
  height: 16px;
  margin-left: 12px;
  margin-right: 8px;
}
 .header-box .header-bottom .input-box input {
  outline: none;
  border: none;
  width: 227px;
  height: 22px;
  font-size: 16px;
  font-family: PingFangSC-Regular, PingFang SC;
  font-weight: 400;
  line-height: 22px;
  background-color: transparent;
  color: #D6D6D6;
}
 .header-box .header-bottom  label {
  display: flex;
}
 .header-box .header-bottom img {
  display: block;
  width: 16px;
  height: 16px;
  margin-left: 12px;
  margin-right: 4px;
}
 .header-box .header-bottom .filter {
  width: 28px;
  height: 20px;
  font-size: 14px;
  font-family: PingFangSC-Regular, PingFang SC;
  font-weight: 400;
  color: #EB1E23;
  line-height: 20px;
}
 .content-box {
  width: 100%;
  height: 664px;
  background: -webkit-gradient(linear, left top, left bottom, from(#FFFFFF), to(#FAFAFA));
  background: linear-gradient(180deg, #FFFFFF 0%, #FAFAFA 100%);
  overflow: hidden;
}
 .content-box img {
  display: block;
  width: 200px;
  height: 120px;
  margin: 0 auto;
  margin-top: 181px;
}
 .login-footer {
  position: absolute;
  bottom: 9px;
  left: 50%;
  -webkit-transform: translateX(-50%);
          transform: translateX(-50%);
  width: 134px;
  height: 5px;
  background: #000;
  border-radius: 100px;
}
</style>