<template>
  <div class="login-box">
        <!-- 背景图 -->
        <div class="bg"></div>
       <router-view></router-view>
        <!-- 登陆界面 -->
        <div class="login-wrap">
            <div class="login-top">
                <div class="time-box">
                    9:41
                </div>
                <div class="signal">
                    <img src="@/assets/images/signal.png" alt="img">
                </div>
                <div class="wifi">
                    <img src="@/assets/images/wifi.png" alt="img">
                </div>
                <div class="electric">
                    <img src="@/assets/images/electric.png" alt="img">
                </div>
            </div>
            <!-- 登陆核心部分 -->
            
            <div class="login-content">
                <div class="logo">
                </div>
                <div class="login-inner">
                    登录
                </div>
                <div class="account" >
                    <input type="text" placeholder="请输入账号" v-model="account">
                </div>
                <div class="password" >
                    <div class="password-box">
                        <input type="password" placeholder="请输入密码" v-model="password">
                        <a href="#"><i @click="eye"></i></a>
                    </div>
                </div>
                <div class="login-button-box">
                    <button @click="screen">登录</button>
                </div>
                <div class="modify">
                    <router-link href="#" to="/layout/register">修改密码</router-link>
                </div>
            </div>
            
        </div>
    </div>
</template>

<script>
    export default {
        name: 'Layout',
        data(){
            return {
                account:'',
                password: '',
            }
        },
        methods: {
            screen(){
                this.$router.push({
                    path: "/layout/screen"
                })
            }
        }
    }
</script>

<style scoped>
input::-webkit-input-placeholder {
        color: #D6D6D6;
    }
    .login-box {
        width: 375px;
        height: 812px;
        background-color: #F5F5F5;
        margin: 0 auto;
        position: relative;
        overflow: hidden;
    }
    .login-box .bg {
        position: absolute;
        top: 0;
        left: 0;
        width: 375px;
        height: 380px;
        background: url(@/assets/images/loginbgc.png) no-repeat;
        background-size: 375px 380px;
    }
    .login-box .login-wrap {
        position: absolute;
        width: 375px;
        height: 812px;
    }
    .login-top {
        padding-top: 14px;
        display: -webkit-box;
        display: -ms-flexbox;
        display: flex;
        -webkit-box-align: center;
        -ms-flex-align: center;
        align-items: center;
    }
 .login-top .time-box {
        width: 54px;
        height: 18px;
        font-size: 15px;
        font-family: SFProText-Semibold, SFProText;
        font-weight: 600;
        color: #fff;
        line-height: 18px;
        text-align: center;
        margin-left: 21px;
    }
 .login-top .signal {
        margin-left: 215px;
        width: 17px;
        height: 11px;
    }
.login-top .signal img {
        display: block;
        width: 100%;
        height: 100%;
        color: #fff;
    }
.login-top .wifi {
        width: 15px;
        height: 11px;
    }
 .login-top .wifi img {
        display: block;
        width: 100%;
        height: 100%;
    }
.login-top .electric {
        width: 22px;
        height: 11px;
    }
.login-top .electric img {
        display: block;
        width: 100%;
        height: 100%;
    }
    .login-box .login-wrap .login-content {
        width: 351px;
        height: 451px;
        background: #FFFFFF;
        -webkit-box-shadow: 0px 0px 4px 0px rgba(0, 0, 0, 0.08);
        box-shadow: 0px 0px 4px 0px rgba(0, 0, 0, 0.08);
        border-radius: 20px;
        margin: 0 auto;
        margin-top: 108px;
        display: -webkit-box;
        display: -ms-flexbox;
        display: flex;
        -webkit-box-orient: vertical;
        -webkit-box-direction: normal;
            -ms-flex-direction: column;
                flex-direction: column;
        -webkit-box-align: center;
            -ms-flex-align: center;
                align-items: center;
    }
    .login-box .login-wrap .login-content .logo {
        width: 80px;
        height: 80px;
        margin-top: -40px;
        background: url(@/assets/images/logo2.png) no-repeat;
        background-size: 80px 80px;
    }
    .login-box .login-wrap .login-content .login-inner {
        width: 48px;
        height: 33px;
        font-size: 24px;
        font-family: PingFangSC-Medium, PingFang SC;
        font-weight: 500;
        color: #333333;
        line-height: 33px;
        margin: 40px 0;
    }
    .login-box .login-wrap .login-content .account {
        margin-bottom: 20px;
        color: #D6D6D6;
        width: 311px;
        height: 48px;
        background: #F5F5F5;
        border-radius: 8px;
    }
    .login-box .login-wrap .login-content .account input {
        outline: none;
        border: none;
        width: 279px;
        height: 22px;
        color: #D6D6D6;
        font-size: 16px;
        font-family: PingFangSC-Regular, PingFang SC;
        font-weight: 400;
        line-height: 22px;
        background-color: transparent;
        margin: 13px 16px;
    }
    .login-box .login-wrap .login-content .password {
        margin-bottom: 28px;
        color: #D6D6D6;
        width: 311px;
        height: 48px;
        background: #F5F5F5;
        border-radius: 8px;
    }
    .login-box .login-wrap .login-content .password .password-box {
        position: relative;
        width: 279px;
        height: 22px;
        margin: 13px 16px;
    }
    .login-box .login-wrap .login-content .password .password-box input {
        outline: none;
        border: none;
        width: 279px;
        height: 22px;
        font-size: 16px;
        font-family: PingFangSC-Regular, PingFang SC;
        font-weight: 400;
        line-height: 22px;
        background-color: transparent;
        color: #D6D6D6;
    }
    .login-box .login-wrap .login-content .password .password-box i {
        position: absolute;
        top: 50%;
        right: 0;
        -webkit-transform: translateY(-50%);
                transform: translateY(-50%);
        width: 16px;
        height: 16px;
        background: url(@/assets/images/eyeclose.png) no-repeat;
        background-size: 16px 16px;
    }
    .login-box .login-wrap .login-content .login-button-box {
        width: 311px;
        height: 48px;
        background: #F58287;
        border-radius: 8px;
        display: -webkit-box;
        display: -ms-flexbox;
        display: flex;
        -webkit-box-pack: center;
            -ms-flex-pack: center;
                justify-content: center;
        -webkit-box-align: center;
            -ms-flex-align: center;
                align-items: center;
        margin-bottom: 20px;
    }
    .login-box .login-wrap .login-content .login-button-box button {
        cursor: pointer;
        width: 287px;
        height: 22px;
        font-size: 16px;
        font-family: PingFangSC-Semibold, PingFang SC;
        font-weight: 600;
        background-color: transparent;
        border: none;
        color: #fff;
        line-height: 22px;
    }
    .login-box .login-wrap .login-content .modify a {
        width: 64px;
        height: 22px;
        font-size: 16px;
        font-family: PingFangSC-Regular, PingFang SC;
        font-weight: 400;
        color: #EB1E23;
        line-height: 22px;
        text-decoration: none;
    }
    
</style>