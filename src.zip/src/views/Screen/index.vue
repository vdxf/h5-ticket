<template>
  <div class="screenall">
     <div class="header-box">
        <div class="login-top">
            <div class="time-box">
                9:41
            </div>
            <div class="signal">
                <img src="@/assets/images/signal.png" alt="img">
            </div>
            <div class="wifi">
                <img src="@/assets/images/wifi.png" alt="img">
            </div>
            <div class="electric">
                <img src="@/assets/images/electric.png" alt="img">
            </div>
        </div>
        <div class="header-content">
            <div class="merchant">
                <a href="#">{商户名称}</a>
            </div>
            <div class="salesman">
                <a href="#">业务员名称</a>
            </div>
            <a href="#"><img src="@/assets/images/exit.png" alt="img"></a>
            <div class="exit">
                <router-link  to="/layout">退出</router-link>
            </div>
        </div>
        <div class="header-bottom">
            <div class="input-box">
                <img src="@/assets/images/search.png" alt="img">
                <input type="text" placeholder="搜索车牌号">
            </div>
            <label>
              <img src="@/assets/images/filter.png" alt="img">
             <router-link  to="/layout/screen/screenlist" class="filter">筛选</router-link>
            </label>
        </div>
    </div>
    <router-view></router-view>  
    <div class="content-box">
        <div class="blue-box">
            <div class="title-box">
                <div class="title">赣A*****(张某华)</div>
                <div class="blue">待发放</div>
            </div>
            <div class="batch-box">
                <div class="batch">券次批号</div>
                <div class="numble">1011321134</div>
            </div>
            <div class="batch-box">
                <div class="batch">批次总金额</div>
                <div class="numble">600.00 (GF:300.00、CX:300.00)</div>
            </div>
            <div class="batch-box">
                <div class="batch">拆分数量</div>
                <div class="numble">2</div>
            </div>
            <div class="batch-box">
                <div class="batch">创建时间</div>
                <div class="numble">2023/07/01 14:00:00</div>
            </div>
        </div>
        <div class="yellow-box">
            <div class="title-box">
                <div class="title">赣A*****(张某华)</div>
                <div class="yellow">部分领取</div>
            </div>
            <div class="batch-box">
                <div class="batch">券次批号</div>
                <div class="numble">1011321134</div>
            </div>
            <div class="batch-box">
                <div class="batch">批次总金额</div>
                <div class="numble">600.00 (GF:300.00、CX:300.00)</div>
            </div>
            <div class="batch-box">
                <div class="batch">拆分数量</div>
                <div class="numble">2</div>
            </div>
            <div class="batch-box">
                <div class="batch">创建时间</div>
                <div class="numble">2023/07/01 14:00:00</div>
            </div>
        </div>
        <div class="red-box">
            <div class="title-box">
                <div class="title">赣A*****(张某华)</div>
                <div class="red">已作废</div>
            </div>
            <div class="batch-box">
                <div class="batch">券次批号</div>
                <div class="numble">1011321134</div>
            </div>
            <div class="batch-box">
                <div class="batch">批次总金额</div>
                <div class="numble">600.00 (GF:300.00、CX:300.00)</div>
            </div>
            <div class="batch-box">
                <div class="batch">拆分数量</div>
                <div class="numble">2</div>
            </div>
            <div class="batch-box">
                <div class="batch">创建时间</div>
                <div class="numble">2023/07/01 14:00:00</div>
            </div>
        </div>
    </div>
  </div>
</template>

<script>
    export default {
        name: 'ScreenAll'
    }
</script>

<style lang="scss" scoped>
a {
  text-decoration: none;
  color: #fff;
}
input::-webkit-input-placeholder {
    color: #D6D6D6;
}
    .screenall {
        width: 375px;
        height: 812px;
        margin: 0 auto;
        position: relative;
        .header-box {
            width: 375px;
            height: 144px;
            background: #EB1E23;
            .login-top {
                padding-top: 14px;
                display: flex;
                align-items: center;
                .time-box {
                    width: 54px;
                    height: 18px;
                    font-size: 15px;
                    font-family: SFProText-Semibold, SFProText;
                    font-weight: 600;
                    color: #fff;
                    line-height: 18px;
                    text-align: center;
                    margin-left: 21px;
                }
                .signal {
                    margin-left: 215px;
                    width: 17px;
                    height: 11px;
                    img {
                        display: block;
                        width: 100%;
                        height: 100%;
                        color: #fff;
                    }
                }
                .wifi {
                    width: 15px;
                    height: 11px;
                    img {
                        display: block;
                        width: 100%;
                        height: 100%;
                    }
                }
                .electric {
                    width: 22px;
                    height: 11px;
                    img {
                        display: block;
                        width: 100%;
                        height: 100%;
                    }
                }
            }
            .header-content {
                width: 100%;
                height: 24px;
                margin-top: 22px;
                display: flex;
                align-items: center;
                justify-content: center;
                .merchant {
                    margin-left: 12px;
                    width: 90px;
                    height: 24px;
                    font-size: 18px;
                    font-family: PingFangSC-Medium, PingFang SC;
                    font-weight: 500;
                    color: #fff;
                    line-height: 24px;
                }
                .salesman {
                    width: 205px;
                    height: 20px;
                    font-size: 15px;
                    font-family: PingFangSC-Medium, PingFang SC;
                    font-weight: 500;
                    color: #fff;
                    line-height: 20px;
                }
                img {
                    display: block;
                    width: 16px;
                    height: 16px;
                }
                .exit {
                    width: 28px;
                    height: 20px;
                    font-size: 14px;
                    font-family: PingFangSC-Regular, PingFang SC;
                    font-weight: 400;
                    color: #FFFFFF;
                    line-height: 20px;
                    margin-left: 4px;
                }
            }
            .header-bottom {
                width: 375px;
                height: 60px;
                margin-top: 10px;
                background: #fff;
                border-radius: 20px 20px 0px 0px;
                display: flex;
                align-items: center;
                .input-box {
                    width: 291px;
                    height: 36px;
                    background: #F5F5F5;
                    border-radius: 8px;
                    margin-left: 12px;
                    display: flex;
                    align-items: center;
                    img {
                        display: block;
                        width: 16px;
                        height: 16px;
                        margin-left: 12px;
                        margin-right: 8px;
                    }
                    input {
                        outline: none;
                        border: none;
                        width: 227px;
                        height: 22px;
                        font-size: 16px;
                        font-family: PingFangSC-Regular, PingFang SC;
                        font-weight: 400;
                        line-height: 22px;
                        background-color: transparent;
                        color: #D6D6D6;
                    }
                }
                label {
                    display: flex;
                    img {
                        display: block;
                        width: 16px;
                        height: 16px;
                        margin-left: 12px;
                        margin-right: 4px;
                    }
                    .filter {
                        width: 28px;
                        height: 20px;
                        font-size: 14px;
                        font-family: PingFangSC-Regular, PingFang SC;
                        font-weight: 400;
                        color: #EB1E23;
                        line-height: 20px;
                    }
                }
            }
        }
        .content-box {
            width: 100%;
            height: 752px;
            background-color: #fff;
            padding: 0 12px;
            .blue-box,.yellow-box,.red-box {
                width: 351px;
                height: 186px;
                background: #FFFFFF;
                box-shadow: 0px 0px 4px 0px rgba(0,0,0,0.08);
                border-radius: 8px;
                margin-bottom: 12px;
                padding: 16px;
                .title-box {
                    display: flex;
                    flex-direction: row;
                    justify-content: space-between;
                    margin-bottom: 16px;
                    .title {
                    width: 132px;
                    height: 22px;
                    font-size: 16px;
                    font-family: PingFangSC-Medium, PingFang SC;
                    font-weight: 500;
                    color: #333333;
                    line-height: 22px;
                    } 
                    @mixin color {
                        width: 56px;
                        height: 16px;
                        border-radius: 2px;
                        font-size: 12px;
                        font-family: PingFangSC-Regular, PingFang SC;
                        font-weight: 400;
                        color: #FFFFFF;
                        line-height: 16px;
                        text-align: center;
                    }
                    .blue {
                        @include color;
                        background-color: #2061E6;
                    }
                    .yellow {
                        @include color;
                        background-color: #FF9601;
                    }
                    .red {
                        @include color;
                        background-color: #EB1E23;
                    }
                }
                .batch-box {
                    display: flex;
                    flex-direction: row;
                    justify-content: space-between;
                    margin-bottom: 12px;
                    .batch {
                        height: 20px;
                        font-size: 14px;
                        font-family: PingFangSC-Regular, PingFang SC;
                        font-weight: 400;
                        color: #999999;
                        line-height: 20px;
                    }
                    .numble {
                        font-size: 14px;
                        font-family: PingFangSC-Regular, PingFang SC;
                        font-weight: 400;
                        color: #333333;
                        line-height: 20px;
                    }
                }
            }
        }
    }
</style>