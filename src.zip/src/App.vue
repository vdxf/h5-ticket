<template>
 <div>
  <router-view></router-view>
  <!-- <ScreenList/> -->
  <!-- <Tickets/> -->
  <!-- <Register/> -->
  <!-- <Popup/> -->
 </div>
</template>

<script>
// import Popup from '@/views/Popup'
// import Register from '@/views/Register'
// import ScreenList from '@/views/ScreenList'
// import Tickets from '@/views/Tickets'
// import Vue from 'vue'
// import { Button } from 'vant';
// Vue.use(Button);

export default {
  name: 'App',
  components: {
    // Popup
    // ScreenList
    // Tickets
    // Register
  }
}
</script>